package com.zrapp.entertainment.ZrService;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.zrapp.entertainment.Activity.MainActivity;
import com.zrapp.entertainment.Activity.MusicActivity;
import com.zrapp.entertainment.Activity.SignInActivity;
import com.zrapp.entertainment.Adapter.MusicAdapter;
import com.zrapp.entertainment.Async.NewsDownload;
import com.zrapp.entertainment.Model.Song;
import com.zrapp.entertainment.Model.User;
import com.zrapp.entertainment.R;
import com.zrapp.entertainment.SQLite.DAO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class ZrService extends IntentService {
    private static Context context;
    private
    DAO dao;
    public static User statusUser = null;
    public static MediaPlayer player;
    public static int postion = 0;

    public ZrService() {
        super("ZrService");
    }

    public ZrService(Context context) {
        super("ZrService");
        this.context = context;
        dao = new DAO(context);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {return null;}

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {}

    public class LocalBinder extends Binder {
        LocalBinder getLocalBinder() {
            return LocalBinder.this;
        }
    }

    public void loadNews(String str, RecyclerView rcv) {
        NewsDownload download = new NewsDownload((MainActivity) context, rcv);
        download.execute(str);
    }

    public void register(User user) {
        if (!dao.isNotEXISTS(user.getUsername()))
            Toast.makeText(context, "Username đã tồn tại", Toast.LENGTH_SHORT).show();
        else {
            dao.insertUser(user);
            Toast.makeText(context, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    Intent intent = new Intent(context, SignInActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            }, 1500);
        }
    }

    public void signIn(User user) {
        if (dao.isNotEXISTS(user.getUsername()))
            Toast.makeText(context, "Tài khoản không tồn tại", Toast.LENGTH_SHORT).show();
        else if (!user.getPassword().equals(dao.getUser(user.getUsername()).getPassword()))
            Toast.makeText(context, "Sai mật khẩu", Toast.LENGTH_SHORT).show();
        else {
            statusUser = dao.getUser(user.getUsername());
            Toast.makeText(context, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    Intent intent = new Intent(context, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            }, 1000);
        }
    }

    public Bitmap getBitmap(byte[] img) {
        return BitmapFactory.decodeByteArray(img, 0, img.length);
    }

    //Xử lý nhạc
    public ArrayList<Song> getList() {
        ArrayList<Song> list = new ArrayList<>();
        String[] projection = {
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.ARTIST,
                MediaStore.MediaColumns.DATA
        };
        Cursor c = context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection, MediaStore.MediaColumns.DURATION + ">?", new String[]{"30000"}, null);
        c.moveToFirst();
        while (!c.isAfterLast()) {
            Song song = new Song();
            song.setTitle(c.getString(0));
            song.setAuthor(c.getString(1));
            song.setPath(c.getString(2));
            c.moveToNext();
            list.add(song);
        }
        c.close();
        return list;
    }

    public void loadPlaylist(RecyclerView rcv) {
        MusicAdapter adapter = new MusicAdapter(getList(), context, R.layout.item_row_music);
        rcv.setAdapter(adapter);
    }

    public void newPlayer(String str) {
        Uri uri = Uri.parse(str);
        player = MediaPlayer.create(context, uri);
        setTitle();
        player.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK);
        setTime();
    }

    public void setTitle(){
        String song = getList().get(postion).getTitle().substring(0, getList().get(postion).getTitle().length() - 4) + " ";
        MusicActivity.tvSong.setText(song);
        MusicActivity.tvAuthor.setText(getList().get(postion).getAuthor());
    }

    public void play() {
        if (player.isPlaying()) {
            player.pause();
            MusicActivity.imgPlay.setImageResource(R.drawable.ic_play);
            MusicActivity.stopEffect();
        } else {
            player.start();
            updateSong();
            MusicActivity.imgPlay.setImageResource(R.drawable.ic_pause);
            MusicActivity.effect();
        }
        updateTime();
    }

    public void next() {
        player.stop();
        isLastSong();
        updateSong();
        setTime();
        updateTime();
        MusicActivity.imgPlay.setImageResource(R.drawable.ic_pause);
        MusicActivity.effect();
    }

    public void prev() {
        player.stop();
        isFirstSong();
        updateSong();
        setTime();
        updateTime();
        MusicActivity.imgPlay.setImageResource(R.drawable.ic_pause);
        MusicActivity.effect();
    }

    public void selectedSong(int i){
        postion =i;
        player.stop();
        Uri uri = Uri.parse(getList().get(i).getPath());
        player = MediaPlayer.create(context, uri);
        String song = getList().get(i).getTitle().substring(0, getList().get(i).getTitle().length() - 4) + " ";
        MusicActivity.tvSong.setText(song);
        MusicActivity.tvAuthor.setText(getList().get(i).getAuthor());
        setTime();
        player.start();
        updateSong();
        MusicActivity.imgPlay.setImageResource(R.drawable.ic_pause);
        MusicActivity.effect();
        updateTime();
    }

    public void onBar() {
        MusicActivity.bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {}

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                player.seekTo(MusicActivity.bar.getProgress());
            }
        });
    }

    public void updateSong() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        isLastSong();
                    }
                });
            }
        }, 100);
    }

    public void isFirstSong() {
        postion--;
        if (postion < 0) {
            postion = getList().size() - 1;
        }
        newPlayer(getList().get(postion).getPath());
        player.start();
    }

    public void isLastSong() {
        postion++;
        if (postion == getList().size()) {
            postion = 0;
        }
        newPlayer(getList().get(postion).getPath());
        player.start();
    }

    public void setTime() {
        SimpleDateFormat minute = new SimpleDateFormat("mm:ss");
        MusicActivity.tvEnd.setText(minute.format(player.getDuration()));
        MusicActivity.bar.setMax(player.getDuration());
    }

    public void updateTime() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat minute = new SimpleDateFormat("mm:ss");
                MusicActivity.tvStart.setText(minute.format(player.getCurrentPosition()));
                MusicActivity.bar.setProgress(player.getCurrentPosition());
                handler.postDelayed(this, 500);
            }
        }, 100);
    }

}
