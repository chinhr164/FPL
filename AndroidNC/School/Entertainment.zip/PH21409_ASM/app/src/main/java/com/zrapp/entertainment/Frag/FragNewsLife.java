package com.zrapp.entertainment.Frag;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.zrapp.entertainment.R;
import com.zrapp.entertainment.ZrService.ZrService;

public class FragNewsLife extends Fragment {
    RecyclerView rcv;
    ZrService zrService;
    ServiceConnection sv_conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            ZrService.LocalBinder localBinder = (ZrService.LocalBinder) iBinder;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {}
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_news_life, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        zrService = new ZrService();
        Intent intentService = new Intent(getActivity(), ZrService.class);
        getActivity().bindService(intentService, sv_conn, Context.BIND_AUTO_CREATE);
        zrService = new ZrService(getContext());
        rcv = view.findViewById(R.id.rcv_news_life);
        zrService.loadNews("https://vnexpress.net/rss/gia-dinh.rss", rcv);
    }
}
