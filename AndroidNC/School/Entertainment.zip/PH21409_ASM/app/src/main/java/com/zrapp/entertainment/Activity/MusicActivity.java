package com.zrapp.entertainment.Activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.navigation.NavigationView;
import com.zrapp.entertainment.R;
import com.zrapp.entertainment.ZrService.ZrService;

public class MusicActivity extends AppCompatActivity {
    Toolbar toolbar;
    DrawerLayout layout;
    NavigationView navigationView;
    RecyclerView rcv;
    public static BottomSheetBehavior sheetBehavior;
    LinearLayout linearLayout, music_top;
    public static ImageView imgBox, imgDisc, imgPlay, imgPrev, imgNext, imgList, imgFav;
    public static TextView tvSong, tvAuthor, tvStart, tvEnd;
    public static SeekBar bar;
    private static Runnable runnable;
    private static Handler handler = new Handler();
    ZrService zrService;
    ServiceConnection sv_conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            ZrService.LocalBinder localBinder = (ZrService.LocalBinder) iBinder;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        zrService = new ZrService();
        Intent intentService = new Intent(getApplicationContext(), ZrService.class);
        bindService(intentService, sv_conn, Context.BIND_AUTO_CREATE);
        zrService = new ZrService(getApplicationContext());

        findView();
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Class aClass = null;
                int id = item.getItemId();
                if (id == R.id.nav_Info) {
                    if (ZrService.statusUser != null) {
                        Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getApplicationContext(), "Chưa đăng nhập >.<!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    switch (id) {
                        case R.id.nav_Home:
                            aClass = MainActivity.class;
                            break;

                        case R.id.nav_SignIn:
                            if (item.getTitle().equals("Đăng xuất")) {
                                ZrService.statusUser = null;
                            }
                            aClass = SignInActivity.class;
                            break;
                    }
                    Intent intent = new Intent(getApplicationContext(), aClass);
                    startActivity(intent);
                }
                return true;
            }
        });

        navSignIn();

        sheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED: {
                        music_top.setVisibility(View.GONE);
                    }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {
                        music_top.setVisibility(View.VISIBLE);
                        Animation animationDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_down);
                        music_top.startAnimation(animationDown);
                    }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });

        zrService.loadPlaylist(rcv);
        zrService.newPlayer(zrService.getList().get(ZrService.postion).getPath());
        zrService.setTitle();

        imgPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                zrService.play();
            }
        });

        imgNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                zrService.next();
            }
        });

        imgPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                zrService.prev();
            }
        });

        imgList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            }
        });

        zrService.onBar();
    }

    @Override
    protected void onResume() {
        super.onResume();
        navSignIn();
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                layout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void findView() {
        toolbar = findViewById(R.id.toolbar);
        layout = findViewById(R.id.drawbleLayout);
        navigationView = findViewById(R.id.nav_menu);
        rcv = findViewById(R.id.music_rcv);
        linearLayout = findViewById(R.id.layout_bottom);
        sheetBehavior = BottomSheetBehavior.from(linearLayout);
        music_top = findViewById(R.id.music_top);
        imgBox = findViewById(R.id.music_box);
        imgDisc = findViewById(R.id.music_disc);
        imgPlay = findViewById(R.id.music_play);
        imgPrev = findViewById(R.id.music_prev);
        imgNext = findViewById(R.id.music_next);
        imgList = findViewById(R.id.music_list);
        imgFav = findViewById(R.id.music_favorite);
        tvSong = findViewById(R.id.music_song);
        tvAuthor = findViewById(R.id.music_author);
        tvStart = findViewById(R.id.music_start);
        tvEnd = findViewById(R.id.music_end);
        bar = findViewById(R.id.music_bar);
    }

    public void navSignIn() {
        MenuItem menuItem = navigationView.getMenu().findItem(R.id.nav_SignIn);
        if (ZrService.statusUser != null) {
            menuItem.setTitle("Đăng xuất");
            menuItem.setIcon(R.drawable.ic_logout);
        } else {
            menuItem.setTitle("Đăng nhập");
            menuItem.setIcon(R.drawable.ic_login);
        }
    }

    public static void effect() {
        runnable = new Runnable() {
            @Override
            public void run() {
                String f = tvSong.getText().toString().substring(0, 1);
                String s = tvSong.getText().toString().substring(1);
                if (f.equals(" ")) {
                    f = tvSong.getText().toString().substring(0, 2);
                    s = tvSong.getText().toString().substring(2);
                }
                tvSong.setText(s + f);
                handler.postDelayed(this, 2000);
            }
        };
        handler.postDelayed(runnable, 2000);
    }

    public static void stopEffect() {
        handler.removeCallbacks(runnable);
    }
}