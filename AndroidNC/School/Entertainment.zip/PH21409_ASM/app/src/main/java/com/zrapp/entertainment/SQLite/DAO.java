package com.zrapp.entertainment.SQLite;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.zrapp.entertainment.Model.User;
import com.zrapp.entertainment.R;

import java.io.ByteArrayOutputStream;

public class DAO {
    Context context;
    private DbHelper dbHelper;
    public DAO(Context context) {
        this.context = context;
        this.dbHelper = new DbHelper(context);
    }

    public User getUser(String str) {
        User user = new User();
        Cursor c = dbHelper.getData("SELECT * FROM User WHERE username = '" + str + "'");
        c.moveToFirst();
        user.setUsername(c.getString(0));
        user.setPassword(c.getString(1));
        user.setName(c.getString(2));
        user.setTel(c.getString(3));
        user.setEmail(c.getString(4));
        user.setAvatar(c.getBlob(5));
        user.setCover(c.getBlob(6));
        return user;
    }

    public void insertUser(User user) {
        String sql = "INSERT INTO User VALUES(?,?,?,?,?,?,?)";
        SQLiteStatement statement = dbHelper.queryData().compileStatement(sql);
        statement.bindString(1, user.getUsername());
        statement.bindString(2, user.getPassword());
        statement.bindString(3, user.getName());
        statement.bindString(4, user.getTel());
        statement.bindString(5, user.getEmail());
        statement.bindBlob(6, getBlob(R.drawable.ava_default));
        statement.bindBlob(7, getBlob(R.drawable.cover_default));
        statement.executeInsert();
    }

    public void updateUser(User user, String username) {
        String sql = "UPDATE User SET " +
                "name=?," +
                "tel=?," +
                "email=? " +
                "WHERE username=?";
        SQLiteStatement statement = dbHelper.queryData().compileStatement(sql);
        statement.bindString(1, user.getName());
        statement.bindString(2, user.getTel());
        statement.bindString(3, user.getEmail());
        statement.bindString(4, username);
        statement.executeUpdateDelete();
    }

    public void updateIMG(String str, User user, byte[] img) {
        String sql = "UPDATE User SET " +
                str + "=? " +
                "WHERE username=?";
        SQLiteStatement statement = dbHelper.queryData().compileStatement(sql);
        statement.bindBlob(1, img);
        statement.bindString(2, user.getUsername());
        statement.executeUpdateDelete();
    }

    public void updatePass(String pass, String username) {
        String sql = "UPDATE User SET " +
                "password=? " +
                "WHERE username=?";
        SQLiteStatement statement = dbHelper.queryData().compileStatement(sql);
        statement.bindString(1, pass);
        statement.bindString(2, username);
        statement.executeUpdateDelete();
    }

    public boolean isNotEXISTS(String str) {
        if (dbHelper.getData("SELECT * FROM User WHERE username = '" + str + "'").getCount() == 0)
            return true;
        return false;
    }

    public byte[] getBlob(int img) {
        //Chuyển ImageView -> byte[]
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), img);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArray);
        return byteArray.toByteArray();
    }
}
