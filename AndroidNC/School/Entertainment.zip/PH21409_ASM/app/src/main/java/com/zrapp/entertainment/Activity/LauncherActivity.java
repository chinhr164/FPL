package com.zrapp.entertainment.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zrapp.entertainment.R;

import java.util.Timer;
import java.util.TimerTask;

public class LauncherActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        Toast.makeText(LauncherActivity.this, "Made by ChinhRoronoa", Toast.LENGTH_SHORT).show();
        Toast.makeText(LauncherActivity.this, "Support by AssassinCode", Toast.LENGTH_SHORT).show();

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(LauncherActivity.this, MainActivity.class);
                startActivity(intent);
            }
        }, 4200);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(LauncherActivity.this, "Thank You", Toast.LENGTH_SHORT).show();
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                finish();
            }
        }, 2500);
    }
}