package com.fpoly.lab7.bai1;

public class Vuong extends ChuNhat {
    public Vuong(double canh) {
        super(canh, canh);
    }

    public void xuat() {
        super.xuat();
    }
}
